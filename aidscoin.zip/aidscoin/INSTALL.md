Building AIDScoin
================

See doc/build-*.md for instructions on building the various
elements of the AIDScoin Core reference implementation of AIDScoin.
